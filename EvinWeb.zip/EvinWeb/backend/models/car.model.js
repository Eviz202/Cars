import mongoose from "mongoose";

const carSchema = new mongoose.Schema({
    name:{
        type: String,
        required: true
    },
    price: {
        type: Number,
        required: true
    },
    image: {
        type: String,
        required: true
    },
}, {
    timestamps: true 
});
const Car = mongoose.model('Cars', carSchema);

export default Car;