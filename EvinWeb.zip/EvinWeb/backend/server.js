import express from 'express';
import dotenv from "dotenv";
import { connectDB } from './config/db.js';
import Car from './models/car.model.js';

dotenv.config();

//const express = require('express');

const app = express();


app.get("/api/cars", async (req,res) => {
    try {
        const cars = await Car.find({});
        res.status(200).json({sucess: true, data: cars });
    } catch (error) {
        console.log("eror in fetching products:", error.message);
        res.status(500).json({ sucess: false, messahe: "Server Error" });
    }
})
app.post("api/cars", async (req, res) => {
    const car = req.body; // user will send this data

    if(!car.name || !car.price || !car.image) {
        return res.status(400).json({sucess:false, message: "please provide all fields"});
    }

    const newCar = new Car(car)

    try {
        await newCar.save();
        res.status(201).json({sucess: true, data: newCar});
    } catch (error) {
        console.error("Error in Create car:", error.message)
        res.status(500).json({ sucess: false, message: "Server Error" });
    }
});

console.log(process.env.MONGO_URI)

app.put("/api/cars/:id", async (req, res) => {
    const { id } = req.params;

    const car = req.body;

    try {
        const updatedCar= await Car.findByIdAndUpdate(id, car,{new:true});
    } catch (error) {
      res.status(500).json({ sucess: false, message: "server error"});
    }
})

app.delete("/api/products/:id", async (req, res) => {
    const {id} =req.params

    try {
        await Car.findByIdAndDelete(id);
        res.status(200).json({ sucess: true, message: "Car deleted" });
    } catch (error) {
        console.log("error in deleting products:", error.message);
        res.status(404).json({ sucess: false, message: "Car not found"});
    }
});

app.listen(5000, () => {
    connectDB();
    console.log("Server started at http://localhost:5000 ");
});

